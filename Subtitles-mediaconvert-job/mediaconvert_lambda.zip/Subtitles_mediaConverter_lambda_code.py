#!/usr/bin/python
# -*- coding: utf-8 -*-
import boto3
import json
import logging
import uuid
import os
import sys
from pathlib import Path
s3 = boto3.client('s3')
mc_client = boto3.client('mediaconvert', region_name='us-east-1')


logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def lambda_handler(event, context):
    logger.info('request: {}'.format(event))
    account_ID = context.invoked_function_arn.split(':')[4]
    record = event['Records'][0]
    s3srcbucket = record['s3']['bucket']['name']
    s3srcobject = record['s3']['object']['key']
    video_name = Path(s3srcobject).stem
    dest_bucket = os.environ['Destination_Bucket']
    s3origsrcbucket = os.environ['Source_Orig_Bucket']
    s3origsrcbucketprefix = os.environ['Source_Orig_Bucket_Prefix']
    dest_prefix = os.environ['Destination_Bucket_Prefix']
    dest_prefix_video = os.environ['Destination_Bucket_Prefix_Video']
    mediaconvert_role_arn = os.environ['MediaConvert_Role_ARN']
    print(s3srcbucket)
    print(dest_bucket)
    print (s3srcobject)
    print(video_name)
    origsrcwithlang = Path(s3srcobject).name.split('-', 2)
    origsrc = origsrcwithlang[0].split('.', 1)

    # Apprnding directory into the key

    orig_key = s3origsrcbucketprefix + '/' + origsrc[1]

    # Video Destination

    dest_key_video = dest_prefix_video + '/' + origsrc[1]

    # Caption Destination

    dest_key = dest_prefix + '/' + Path(s3srcobject).name
    print(dest_key)
    print(dest_key_video)

    # Copy Source Object

    copy_source = {'Bucket': s3srcbucket, 'Key': s3srcobject}

 # S3 copy object operation

    s3.copy_object(CopySource=copy_source, Bucket=dest_bucket,
                   Key=dest_key)

    # Copy Original Source Object

    copy_source_orig = {'Bucket': s3origsrcbucket, 'Key': orig_key}
    s3.copy_object(CopySource=copy_source_orig, Bucket=dest_bucket,
                   Key=dest_key_video)
    with open('mediaconvert_settings.json') as json_file:
        mediaconvert_data_set = json.load(json_file)

    #
    # substitute variables in JSON with actual values
    #
    mediaconvert_data_set['Role'] = mediaconvert_role_arn
    mediaconvert_data_set['Queue'] = 'arn:aws:mediaconvert:us-east-1:' \
        + account_ID + ':queues/Default'
    mediaconvert_data_set['Settings']['OutputGroups'
            ][0]['OutputGroupSettings']['FileGroupSettings'
            ]['Destination'] = \
        's3://' + dest_bucket + '/mediaoutput/' \
        + video_name
    mediaconvert_data_set['Settings']['Inputs'][0]['CaptionSelectors'
            ]['Captions Selector 1']['SourceSettings'
            ]['FileSourceSettings']['SourceFile'] = \
        's3://' + dest_bucket + '/' + dest_key
    mediaconvert_data_set['Settings']['Inputs'][0]['FileInput'] = \
        's3://' + dest_bucket + '/' + dest_key_video
    mediaconvert_data_set['Settings']['OutputGroups'
            ][0]['Outputs'][0]['CaptionDescriptions'][0]['DestinationSettings'
            ]['DestinationType'] = 'BURN_IN'
    mediaconvert_data_set['Settings']['OutputGroups'
            ][0]['Outputs'][0]['CaptionDescriptions'][0]['DestinationSettings'
            ]['BurninDestinationSettings']['FontColor'] = 'BLUE'
    mediaconvert_data_set['Settings']['OutputGroups'
            ][0]['Outputs'][0]['CaptionDescriptions'][0]['DestinationSettings'
            ]['BurninDestinationSettings']['Alignment'] = 'CENTERED'
    assetID = str(uuid.uuid4())
    jobMetadata = {}
    jobMetadata['assetID'] = assetID
    jobMetadata['application'] = 'subtitles_media_convert'
    endpoints = mc_client.describe_endpoints()
    print(endpoints['Endpoints'][0]['Url'])

    #
    # create MediaConvert job
    #

    mc = boto3.client('mediaconvert', region_name='us-east-1',
                      endpoint_url=endpoints['Endpoints'][0]['Url'],
                      verify=True)
    job = mc.create_job(Role=mediaconvert_role_arn,
                        UserMetadata=jobMetadata,
                        Settings=mediaconvert_data_set['Settings'])


    # print (str(job))
